/*****************************************************************************/
/*********************************preparation*********************************/
/*****************************************************************************/

//set the port number
var my_port_number = 'ws27';

var max_wait = 5; //5 minutes max wait to be paired

var PROLIFIC_COMPLETION_CODE = "484DA5C2"; 

//generate a random participant ID
//var participant_id = jsPsych.randomization.randomID(10);

/*
Running on Prolific, so can access PROLIFIC_ID as follows.
*/

var PARTICIPANT_ID = jsPsych.data.getURLVariable("PROLIFIC_PID");


//saving data
function save_data(name, data_in) {
    console.log(name,data_in);
    var url = "save_data.php";
    var data_to_send = {filename: name, filedata: data_in};
    fetch(url, {
        method: "POST",
        body: JSON.stringify(data_to_send),
        headers: new Headers({
            "Content-Type": "application/json",
        }),
    });
}

//save dyadic interaction data
function save_dyadic_interaction_data(data) {
    console.log(data)
    var data_to_save = [//ensure the data are recorded.
        PARTICIPANT_ID, //sender id
        data.partner_id, //receiver id
        data.trial_index, //trial no.
        data.trial_type, //two roles
        data.target_meaning, //the meaning pair the sender faced with
        data.foil_meaning,
        data.response_choices.join('-'), //the signals the sender faced with, or the meanings the receiver faced with
        data.signal_selected, //which signal is selected
        data.meaning_selected, //to guess the meaning of the signal

        data.rt, // maybe another criterion for data exclusion?（is this necessary?）
    ];
    
    var line = data_to_save.join(",") + "\n";
    var this_participant_filename = "di_" + PARTICIPANT_ID + ".csv";
    save_data(this_participant_filename, line);
}

var write_headers = {
    type: "call-function",
    func: function () {
        var this_participant_filename = "di_" + PARTICIPANT_ID + ".csv";
        save_data(
            this_participant_filename,
            "participant_id, partner_id, trial_index, trial_type, target_meaning, foil_meaning, \
            choices, signal_selected, meaning_guess, rt\n"
        );
    },
};

//just writing as one string with header attached
function save_demographics_data(demograpics_data) {
    //build filename using the PARTICIPANT_ID
    var filename = "demographics_" + PARTICIPANT_ID + ".csv";
    var headers =
      "participant_id,took_notes,comments,exit_mode\n";
    var data_to_save = [
      PARTICIPANT_ID,
      demograpics_data.notes,
      demograpics_data.comments,
      demograpics_data.exit_mode,
    ];
    var data_line = data_to_save.join(",") + "\n";
    save_data(filename, headers + data_line);
  }

/*****************************************************************************/
/******************************starting the loop******************************/
/*****************************************************************************/
var start_interaction_loop = {
    type: "call-function", 
    func: interaction_loop,
};

/*****************************************************************************/
/*******************************waiting section*******************************/
/*****************************************************************************/

/*
//old waiting room
function waiting_room() {
    var waiting_room_trial = {
        type: "html-button-response",
        stimulus: "You are in the waiting room...",
        choices: [],
        on_finish: function() {
            jsPsych.pauseExperiment();
        },
    };
    jsPsych.addNodeToEndOfTimeline(waiting_room_trial);
    jsPsych.resumeExperiment();
}
*/

function waiting_room() {
    var waiting_text =
    "<p style='text-align:left'>You are in the waiting room. \
    Maximum wait time is " +
    max_wait +
    " minutes.</p>";
    var max_wait_exceeded_text =
    "<p style='text-align:left'>We have been unable to pair you with a partner. \
    Click continue progress to the final screen and finish the experiment.</p>";
    var post_timer_text =
      "<p style='text-align:left'><b>Please monitor this tab</b> - the \
    experiment will resume as soon as you are paired, and your partner will be \
    waiting for you.</p>";
    var max_wait_ms = max_wait * 60 * 1000;
    //timer-related bits and pieces
    var counter;
    var count = 0;
    var minutes = 0;
    var seconds = 0;
    var waiting_room = {
      type: "html-button-response",
      choices: [],
      trial_duration: max_wait_ms,
      stimulus: function () {
        clearInterval(counter);
        counter = setInterval(timer, 1000); //1000 will run it every 1 second
        function timer() {
          count = count + 1;
          minutes = Math.floor(count / 60);
          seconds = count % 60;
          document.getElementById("timer-mins").innerHTML = minutes;
          document.getElementById("timer-seconds").innerHTML = seconds;
        }
        var timer_text =
          "<p style='text-align:left'>You have been \
                          waiting for <span id='timer-mins'>" +
          minutes +
          "</span> minutes \
                          <span id='timer-seconds'>" +
          seconds +
          "</span> seconds</p>";
        return waiting_text + timer_text + post_timer_text;
      },
      on_finish: function (data) {
        clearInterval(counter);
        //data.exp_trial_type = "exit_waiting_room_" + phase;
        //data.stimulus = "";
        //save_al_data(data);
      },
    };
    //this will only be reached if maximum waiting time is exceeded, otherwise this timelien will be killed
    var max_wait_exceeded = {
      type: "html-button-response",
      stimulus: max_wait_exceeded_text,
      choices: ["Continue"],
      on_finish: function () {
        send_to_server({ response_type: "NOT_PAIRED" });
        jsPsych.pauseExperiment();
        end_experiment("not_paired");
      },
    };
    var waiting_room_trial = { timeline: [waiting_room, max_wait_exceeded] };
    jsPsych.addNodeToEndOfTimeline(waiting_room_trial);
    jsPsych.resumeExperiment();
  }
  


//set a waiting room for the partner
function waiting_for_partner() {
    end_waiting();
    var waiting_trial = {
        type: "html-button-response",
        stimulus: "Waiting for your partner's action...",
        choices: [],
        on_finish: function() {
            jsPsych.pauseExperiment();
        },
    };
    jsPsych.addNodeToEndOfTimeline(waiting_trial);
    jsPsych.resumeExperiment();
}

//end waiting
function end_waiting() {
    var current_trial = jsPsych.currentTrial();
    console.log(current_trial)
    if (typeof current_trial !== "undefined") {
        //this is the call-function trial to send the director's response to the server, we can just end it
        if (current_trial.type=="call-function") {
            jsPsych.finishTrial();
            //jsPsych.endCurrentTimeline();//this kills the rest of the production loop timeline?
        }
        else if (current_trial.stimulus.includes("Waiting for your partner")) {
            //waiting trial
            //NB the waiting-for-partner trial will pause the timeline in its on_finish
            jsPsych.finishTrial();
        } 
        else if (current_trial.stimulus.includes("You are in the waiting room")) {
            //waiting room
            jsPsych.pauseExperiment();
            jsPsych.finishTrial();
            jsPsych.endCurrentTimeline();//this kills the rest of the waiting room timeline
        }
    }
}

/****************************Circumstances:***********************************/
/****************************start; drop-out; end*****************************/
/*****************************************************************************/

//start the trial after being paired by sending "complete" to server
function show_interaction_instructions() {
    end_waiting();
    var instruction_screen_interaction = {
        type: "html-button-response",
        stimulus:
        "<h3>Instructions for the Mission</h3>\
                                                    <p style='text-align: left'>In this game, you and your partner will be teaming up and taking turns sending each other encrypted messages using secret codes.</p>\
                                                    <p style='text-align: left'>To make it impossible for the Enemy to decode your correspondence, even you won't know at the start how the secret code language works!</p>\
                                                    <p style='text-align: left'>On each round, both of you will be shown two single-word messages on the screen, for example 'today' and 'tomorrow' (the order of those is random on each screen!).</p>\
                                                    <p style='text-align: left'>As a <b>sender</b>, pick a code from the list to represent the message indicated by an arrow.</p>\
                                                    <p style='text-align: left'>As a <b>receiver</b>, try to guess which of the two messages your partner had in mind.</p>\
                                                    <p style='text-align: left'>Every time you guess correctly, your team's score increases.</p>\
                                                    <p style='text-align:left'><b>Tips:</b><br>\
                                                                                - When sending and guessing the coded messages, try to remember how you and your partner used them in the previous rounds.<br>\
                                                                                - Please communicate only using the game interface; if you signed up with a friend, <b>DO NOT talk during the game</b>.<br>\
                                                                                - <b>DO NOT write anything down</b> (we're interested in what your brain can do!).<br>\
                                                                                - <b>DO NOT</b> use the <b>'back'</b> or <b>'refresh'</b> buttons in your browser.</p>",
        choices: ["I have carefully read the instructions above"],
        on_finish: function() {
            send_to_server({ response_type:"INTERACTION_INSTRUCTIONS_COMPLETE"});
            jsPsych.pauseExperiment();
        },
    };
    jsPsych.addNodeToEndOfTimeline(instruction_screen_interaction);
    jsPsych.resumeExperiment();
}

//when one drops out
function partner_dropout() {
    end_waiting();
    var stranded_screen = {
        type: "html-button-response",
        stimulus: "<h3>Oh no! Something has gone wrong!</h3>\
                                        <p style='text-align:left'>Unfortunately it looks like something has gone wrong - sorry!</p>\
                                        <p style='text-align:left'>Click continue to progress to the final screen and finish the experiment.</p>",
        choices: ["Continue"],
    };
    jsPsych.addNodeToEndOfTimeline(stranded_screen);
    end_experiment("partner_dropout");
}

//old end
/*function end_experiment() {
    var final_screen = {
        type: "html-button-response",
        stimulus:
        "<h3>Finished!</h3>\
                            <p style='text-align:left'>You have completed your mission!</p>\
                            <p style='text-align:left'>Click the button for the intruction to get reward!</p>",
        choices: ["<a href='https://app.prolific.co/submissions/complete?cc=484DA5C2'>Back to Prolific</a>"],
        on_finish: function() {
            close_socket();
            jsPsych.endCurrentTimeline();
        },
    };
    jsPsych.addNodeToEndOfTimeline(final_screen);
    jsPsych.resumeExperiment();
}
*/

function end_experiment(exit_mode) {
    close_socket();
    if (exit_mode=="clean" || exit_mode=="partner_dropout") {
        jsPsych.addNodeToEndOfTimeline(demographics(exit_mode));
    }
    jsPsych.addNodeToEndOfTimeline(final_screen(exit_mode));
    jsPsych.resumeExperiment();
  }
  
  /*
  This could collect more general demographics info, but at present it's just a comments box.
  */
  function demographics(exit_mode) {
    if (exit_mode == "clean") {
      var exit_message =
        "<h3> That's it, you're all done!</h3> \
        <p style='text-align:left'>Congratulations on making it all the way to the end.</p> \
        <p style='text-align:left'>Did you write stuff down or take notes during the task? \
        Please be honest - it won't affect your payment, we promise, and if you tell us now \
        we can correct for this in our analysis without affecting the validity of our experiment.\
        <br><br>\
                  <input type='radio' name='notes' id='notesN' value='no' required/>No I did not make notes<br>\
                  <input type='radio' name='notes' id='notesY' value='yes' required/>OK I confess, I did make notes!</p>\
        <p style='text-align:left'>Please provide any comments you have on the experiment, \
        or anything else you want us to know. We'd be particularly interested to know how you figured out which labels to \
        use to communicate with your partner, and how you decided whether to use short or long labels. If you took notes, \
        you could tell us briefly here what sort of stuff you wrote down.<br><br>\
        <textarea name='comments' rows='10' cols='120'></textarea></p>";
    } 
     else {
         var exit_message =
        "<h3> That's it, you're all done!</h3> \
        <p style='text-align:left'>Did you write stuff down or take notes during the task? \
        Please be honest - it won't affect your payment, we promise, and if you tell us now \
        we can correct for this in our analysis without affecting the validity of our experiment.\
        <br><br>\
                  <input type='radio' name='notes' id='notesN' value='no' required/>No I did not make notes<br>\
                  <input type='radio' name='notes' id='notesY' value='yes' required/>OK I confess, I did make notes!</p>\
        <p style='text-align:left'>Please provide any comments you have on the experiment, \
        or anything else you want us to know. If you took notes, you could tell us briefly\
        here what sort of stuff you wrote down.<br><br>\
        <textarea name='comments' rows='10' cols='120'></textarea></p>";
    }
    var demographics_trial = {
      type: "survey-html-form",
      preamble: "<h3></h3>",
      button_label: "Continue",
      html: exit_message,
      on_finish: function (data) {
        //need to remove commas from responses to avoid messing with CSV data
        var comments = data.response.comments.replace(/,/g, "");
        var demo_data = {notes:data.response.notes, comments: comments, exit_mode: exit_mode };
        save_demographics_data(demo_data);
      },
    };
    return demographics_trial;
  }
  
  /* 
  Redirection to prolific or instructions to return and request a bonus
  */
  function final_screen(exit_mode) {
    if (exit_mode == "clean") {
      var final_trial = {
        type: "html-button-response",
        stimulus:
          "<h3>Finished!</h3>\
          <p style='text-align:left'>Press continue to complete the experiment and \
          submit your completion code to Prolific. Thanks for participating!</p>",
        choices: ["Submit completion code"],
        on_finish: function () {
          window.location =
            "https://app.prolific.co/submissions/complete?cc=" +
            PROLIFIC_COMPLETION_CODE;
        },
      };
    } else {
      var final_trial = {
        type: "html-button-response",
        stimulus:
          "<h3>Finished!</h3>\
          <p style='text-align:left'>Because something went wrong and you weren't able to complete the experiment, we have to pay you by bonus rather than completion code - don't worry, \
          you'll be paid the appropriate amount depending on how far you got through the experiment.</p>\
          <p style='text-align:left'>To get paid: please <b>send us a short message via the Prolific website</b> to let us know you need to be paid by bonus, \
          then <b>return the experiment</b> - this is the method Prolific have asked us to use for partial payment.</p>\
          <p style='text-align:left'>If for any reason you aren't able to message us via Prolific, please email Qingfeng (q.tong@sms.ed.ac.uk)\
            with your Prolific ID and we will make sure you get paid for your time.</p>\
            <p style='text-align:left'>Thanks for participating!</p>",
        choices: [],
      };
    }
  
    return final_trial;
  }

/*****************************************************************************/
/**********************sender (signal selection) trial************************/
/*****************************************************************************/

function sender_trial(target_meaning,foil_meaning, signal_choices, trial_n, max_trial_n,partner_id) {
    end_waiting();
    var sender_stimulus = "<p>"+target_meaning + "\u21E6 </br>" + "<span style='color:grey'>" + foil_meaning + "</span></p>";
    var prompt_text = "<p><em>Trial " + (trial_n+1) + "/" + (max_trial_n+1) + "</em></p>";  
    var n_clicks_required;
    var n_clicks_given = 0;
    var signal_selected;
 
    //subtrial 2: click multiple times, one per signal syllable (or character?).
    var subtrial2 = {
        type: "html-button-response",
        stimulus: sender_stimulus,
        prompt: prompt_text,
        choices: signal_choices,
        
        on_start: function(trial) {
            //var shuffled_signal_choices = jsPsych.randomization.shuffle(signal_choices); 
            var shuffled_signal_choices = signal_choices;
            trial.choices = shuffled_signal_choices;
            trial.data = {
                block: "production",
                target_meaning:target_meaning,
                foil_meaning:foil_meaning,
                response_choices: shuffled_signal_choices,
            };
        },
        on_finish: function(data) {
            var button_number = data.response;
            signal_selected = data.response_choices[button_number];
            data.button_number = button_number;
            data.signal_selected = signal_selected
            signal_length = signal_selected.length;
            n_clicks_required = signal_length;
            if(signal_length < 4) {
                n_clicks_required = 1
                } else {
                n_clicks_required = 4
            }
            data.trial_type = "sender";
            data.partner_id = partner_id;
            save_dyadic_interaction_data(data);
        },
    };

    //specify the number of clicks
    var single_click_trial = {
        type: "html-button-response",
        stimulus: sender_stimulus,
        prompt: "",
        choices: [],

        on_start: function(trial) {
            var prompt_text;
            if (n_clicks_required==1) {prompt_text = "<p>Click 1 time to send!</p>";}
            else {prompt_text = "<p>Click " + n_clicks_required+ " times to send!</p>";}
            trial.choices = [signal_selected],
            trial.prompt = prompt_text
        },
        on_finish: function() {
            n_clicks_given += 1;
        },
    };

    //set the loop
    var subtrial3 = {
        timeline: [single_click_trial],
        loop_function: function() {
            if (n_clicks_given < n_clicks_required) {
                return true;
            } else {
                return false;
            }
        },
    };

    //call-function: let the server know
    var message_to_server = {
        type: "call-function",
        func: function() {
            send_to_server({
                response_type: "RESPONSE",
                participant: PARTICIPANT_ID,
                partner: partner_id,
                role: "Sender",
                response: signal_selected,
            });
            jsPsych.pauseExperiment();
        },
    };

    //connect the trials
    var trial = {
        timeline: [subtrial2, subtrial3, message_to_server],
    };
    jsPsych.addNodeToEndOfTimeline(trial);
    jsPsych.resumeExperiment();
}

/*****************************************************************************/
/*********************receiver (meaning guessing) trial***********************/
/*****************************************************************************/

function receiver_trial(sender_signal, target_meaning, foil_meaning, trial_n, max_trial_n, partner_id) {
    end_waiting();
    var prompt_text = "<p><em>Trial " + (trial_n+1) + "/" + (max_trial_n+1) + "</em></p>";  
    //QT - looks like you were not showing the sender_signal anywhere - I put it in the stimulus.
    var trial = {
        type: "html-button-response",
        stimulus: "<p>"+sender_signal+"</p>", 
        prompt: prompt_text,
        choices: [target_meaning, foil_meaning],//the order of meanings within a pair should be randomized.

        on_start: function(trial) {
            var shuffled_meaning_choices = jsPsych.randomization.shuffle(
                trial.choices
            );
            trial.choices = shuffled_meaning_choices;
            trial.data = {response_choices: shuffled_meaning_choices,
                        target_meaning:target_meaning,
                        foil_meaning:foil_meaning};
        },

        on_finish: function(data) {
            var button_number = data.response;
            data.trial_type = "receiver";
            data.meaning_selected = data.response_choices[button_number];
            data.partner_id = partner_id;
            save_dyadic_interaction_data(data);
            
            send_to_server({
                response_type: "RESPONSE",
                participant: PARTICIPANT_ID,
                partner: partner_id,
                role: "Receiver",
                sender_signal: sender_signal,
                response: data.meaning_selected,
            });
            jsPsych.pauseExperiment();
        },
    };
    jsPsych.addNodeToEndOfTimeline(trial);
    jsPsych.resumeExperiment();
}

/*****************************************************************************/
/******************************feedback screen********************************/
/*****************************************************************************/

function display_feedback(score) {
    end_waiting();
    if (score == 1) {
        var feedback_stimulus = "Correct!";
    } else {
        var feedback_stimulus = "Incorrect!";
    }
    var feedback_trial = {
        type: "html-button-response",
        stimulus: feedback_stimulus,
        choices:[],
        trial_duration: 1500,
        on_finish: function() {
            send_to_server({
                response_type: "FINISHED_FEEDBACK"
            });
            jsPsych.pauseExperiment();
        },
    };
    jsPsych.addNodeToEndOfTimeline(feedback_trial);
    jsPsych.resumeExperiment();
}

/*****************************************************************************/
/*****************************instruction trials******************************/
/*****************************************************************************/

var consent_screen = {
    type: "html-button-response",
    stimulus:
        "<h3>Welcome to the Experiment</h3>\
  <p style='text-align:left'>Thank you for choosing to take part in our study!\
  The full experiment takes about <b>30 minutes</b> to complete and you will be paid <b>&pound;5</b>.</p>\
  \
  <p style='text-align:left'>This experiment is part of a research project conducted by Prof. Kenny \
  Smith and Qingfeng Tong at The University of Edinburgh, and has been approved by the Linguistics and \
  English Language Ethics Committee. <b>Please click here to download a study information letter \
  <a href='S2113119_consentform.pdf' download>(pdf)</a></b>\
  for further information about the study.</p>\
  \
  <p style='text-align:left'><b>This experiment requires you to interact in real time with another \
  participant to complete a espionage game</b>, sending each other labels that convey a secret meaning.\
  Since your partner will be waiting for you throughout the experiment, and depends on your prompt responses to \
  complete the experiment in a timely fashion, please do not participate if you aren't able to give the \
  experiment and your partner your full attention.</p>\
  \
  <p style='text-align:left'><b>Please do not take written notes!</b> In this experiment we \
  are interested in what your brain can do, not what your brain plus a notebook \
  can do, so please don\'t write anything down. Just do your best - \
  we are interested in places where communication breaks down as well as where it succeeds, and we don't expect perfection!</p>\
  \
  <p style='text-align:left'>Clicking on the consent button below indicates that:<br>\
    - You have downloaded and read the information letter<br>\
    - You voluntarily agree to participate<br>\
    - You are at least 18 years of age<br>\
    - You are a native speaker of English<br>\
    If you do not agree to all of these, please do not participate in this experiment.</p>",
    choices: ["Yes, I consent to participate"],
};

var instruction_screen_enter_waiting_room = {
    type: "html-button-response",
    stimulus:
        "<h3>Enter the waiting room and pair with your partner...</h3>\
        <p style='text-align:left'>If your partner becomes non-responsive or something breaks: please <b>send us a short message via the Prolific website</b> to let us know you need to be paid by bonus, \
          then <b>return the experiment</b> - this is the method Prolific have asked us to use for partial payment in the event that people can't complete the experiment.</p>\
          <p style='text-align:left'>If for any reason you aren't able to message us via Prolific, please email Qingfeng (q.tong@sms.ed.ac.uk)\
            with your Prolific ID and we will make sure you get paid for your time.</p>",
        choices: ["Continue"],
};

var preload_trial = {
    type: "preload",
    auto_preload: true,
};

/*****************************************************************************/
/*************************build and run the timeline**************************/
/*****************************************************************************/

var full_timeline = [].concat(
    consent_screen,
    preload_trial,
    instruction_screen_enter_waiting_room,
    write_headers,
    start_interaction_loop
);

jsPsych.init({
    timeline:full_timeline,

});