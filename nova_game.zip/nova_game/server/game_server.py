# -*- coding: utf-8 -*-

###################################################################
############## python server for javascript client ################
###################################################################

# json-encoded
# command_type: let the client know what action to take
# response_type: let the server know what response the client has sent

###################################################################
################ libraries from websocket_server ##################
###################################################################

from websocket_server import WebsocketServer
import random
import json
import csv

from copy import deepcopy

###################################################################
############################ globals ##############################
###################################################################

global_participant_data = {} #indexed by ID
# keys: client_info, partner, role, trial_list, shared_trial_number

unpaired_clients = []
# client IDs while they are in the waiting room to be paired

phase_sequence = ['Start', 'PairParticipants', "Interaction", 'End']

###################################################################
############################ stimuli ##############################
###################################################################



# creating signal set
signal_short = ['wuk', 'haq', 'qip', 'meh', 'kuh', 'hix', 'peh', 'zah', 'qux', 'tih']
signal_long = ['teliqulo', 'ralonefi', 'tezalipu', 'nidaweli', 'puwirefa', 'hiwaponu', 'pofepilu', 'saqotiwe', 'wepitula', 'lehaqifu']




# hard-wiring the meaning set
andres_meaning_list = [['author', 'budget',	'change', 'course', 'former', 'future',	'player', 'public',	'second', 'system'],
                       ['author', 'budget',	'coffee', 'family', 'former', 'ground',	'player', 'public',	'handle', 'window'],
                       ['author', 'budget',	'former', 'ground', 'handle', 'market',	'player', 'public',	'second', 'system'],
                       ['author', 'budget',	'former', 'normal', 'number', 'online',	'people', 'player',	'public', 'second'],
                       ['author', 'budget',	'course', 'family', 'former', 'ground',	'number', 'public',	'second', 'player'],
                       ['author', 'budget', 'change', 'credit', 'former', 'ground', 'number', 'player', 'public', 'travel'],
                       ['author', 'budget', 'credit', 'design', 'former', 'online', 'player', 'public', 'system', 'window'],
                       ['branch', 'credit', 'future', 'garden', 'handle', 'health', 'normal', 'people', 'review', 'school'],
                       ['branch', 'change', 'course', 'credit', 'garden', 'health', 'normal', 'number', 'people', 'school'],
                       ['branch', 'change', 'credit', 'garden', 'health', 'market', 'online', 'school', 'system', 'travel'],
                       ['branch', 'change', 'coffee', 'garden', 'handle', 'health', 'market', 'normal', 'number', 'school'],
                       ['branch', 'garden', 'health', 'market', 'normal', 'number', 'online', 'school', 'second', 'travel'],
                       ['branch', 'change', 'credit', 'design', 'garden', 'handle', 'health', 'normal', 'school', 'second'],
                       ['branch', 'coffee', 'garden', 'health', 'online', 'people', 'school', 'second', 'system', 'travel'],
                       ['branch', 'change', 'credit', 'design', 'garden', 'health', 'online', 'people', 'school', 'window'],
                       ['branch', 'credit', 'future', 'garden', 'ground', 'health', 'normal', 'school', 'second', 'travel'],
                       ['change', 'coffee', 'future', 'ground', 'market', 'normal', 'online', 'people', 'review', 'window'],
                       ['change', 'course', 'credit', 'design', 'family', 'market', 'normal', 'people', 'system', 'weight'],
                       ['change', 'coffee', 'design', 'market', 'number', 'online', 'people', 'review', 'second', 'window'],
                       ['change', 'coffee', 'credit', 'family', 'ground', 'handle', 'market', 'number', 'review', 'travel'],
                       ['change', 'coffee', 'course', 'family', 'future', 'normal', 'number', 'review', 'second', 'travel'],
                       ['change', 'design', 'future', 'handle', 'normal', 'online', 'people', 'second', 'system', 'travel'],
                       ['change', 'coffee', 'credit', 'design', 'family', 'future', 'market', 'second', 'weight', 'window'],
                       ['change', 'course', 'credit', 'ground', 'handle', 'normal', 'number', 'online', 'second', 'window'],
                       ['change', 'coffee', 'course', 'credit', 'family', 'future', 'handle', 'normal', 'online', 'window'],
                       ['change', 'course', 'credit', 'design', 'family', 'future', 'normal', 'online', 'second', 'travel'],
                       ['change', 'coffee', 'design', 'family', 'future', 'ground', 'handle', 'people', 'review', 'window'],
                       ['change', 'credit', 'future', 'handle', 'market', 'number', 'online', 'review', 'system', 'travel'],
                       ['change', 'coffee', 'credit', 'handle', 'normal', 'number', 'people', 'second', 'system', 'window'],
                       ['change', 'credit', 'family', 'future', 'handle', 'market', 'normal', 'online', 'second', 'system'],
                       ['change', 'coffee', 'course', 'family', 'ground', 'handle', 'market', 'review', 'second', 'window'],
                       ['change', 'coffee', 'course', 'design', 'ground', 'handle', 'market', 'normal', 'weight', 'window'],
                       ['change', 'coffee', 'course', 'credit', 'design', 'ground', 'normal', 'review', 'system', 'travel'],
                       ['change', 'course', 'credit', 'design', 'future', 'ground', 'market', 'number', 'review', 'travel'],
                       ['change', 'coffee', 'credit', 'family', 'handle', 'market', 'online', 'review', 'system', 'window'],
                       ['change', 'course', 'credit', 'family', 'ground', 'market', 'number', 'online', 'review', 'system'],
                       ['change', 'coffee', 'course', 'family', 'future', 'handle', 'market', 'normal', 'review', 'system'],
                       ['change', 'course', 'credit', 'family', 'ground', 'normal', 'online', 'people', 'system', 'travel'],
                       ['change', 'coffee', 'credit', 'design', 'family', 'ground', 'market', 'normal', 'number', 'people'],
                       ['change', 'coffee', 'design', 'future', 'handle', 'market', 'normal', 'review', 'travel', 'window'],
                       ['change', 'course', 'design', 'future', 'normal', 'number', 'online', 'people', 'review', 'system'],
                       ['change', 'ground', 'memory', 'online', 'police', 'review', 'signal', 'silver', 'system', 'window'],
                       ['change', 'design', 'ground', 'handle', 'market', 'memory', 'police', 'second', 'signal', 'silver'],
                       ['change', 'coffee', 'course', 'ground', 'handle', 'number', 'people', 'review', 'system', 'weight'],
                       ['change', 'coffee', 'course', 'credit', 'handle', 'market', 'normal', 'second', 'travel', 'window'],
                       ['change', 'course', 'credit', 'design', 'family', 'ground', 'people', 'review', 'second', 'window'],
                       ['change', 'family', 'future', 'handle', 'market', 'normal', 'number', 'online', 'travel', 'window'],
                       ['change', 'credit', 'design', 'market', 'online', 'people', 'review', 'system', 'travel', 'window'],
                       ['change', 'coffee', 'course', 'design', 'handle', 'normal', 'online', 'people', 'review', 'travel'],
                       ['change', 'coffee', 'credit', 'design', 'handle', 'number', 'online', 'second', 'system', 'travel'],
                       ['change', 'coffee', 'family', 'ground', 'memory', 'normal', 'police', 'review', 'signal', 'silver'],
                       ['change', 'course', 'family', 'future', 'handle', 'number', 'review', 'system', 'travel', 'window'],
                       ['change', 'design', 'family', 'future', 'market', 'online', 'second', 'system', 'travel', 'window'],
                       ['change', 'coffee', 'credit', 'future', 'ground', 'people', 'review', 'second', 'travel', 'window'],
                       ['change', 'coffee', 'family', 'future', 'handle', 'number', 'people', 'second', 'system', 'weight'],
                       ['change', 'design', 'family', 'ground', 'normal', 'people', 'second', 'system', 'weight', 'window'],
                       ['change', 'coffee', 'credit', 'design', 'family', 'handle', 'normal', 'online', 'review', 'second'],
                       ['coffee', 'course', 'credit', 'design', 'number', 'people', 'review', 'system', 'travel', 'window'],
                       ['coffee', 'course', 'ground', 'handle', 'market', 'number', 'review', 'travel', 'weight', 'window'],
                       ['coffee', 'course', 'family', 'future', 'ground', 'handle', 'normal', 'review', 'travel', 'window'],
                       ['coffee', 'course', 'future', 'market', 'normal', 'online', 'people', 'second', 'system', 'travel'],
                       ['coffee', 'course', 'credit', 'design', 'future', 'ground', 'handle', 'online', 'people', 'window'],
                       ['coffee', 'course', 'design', 'family', 'future', 'number', 'online', 'people', 'system', 'weight'],
                       ['coffee', 'design', 'family', 'handle', 'market', 'normal', 'online', 'people', 'travel', 'window'],
                       ['coffee', 'credit', 'future', 'ground', 'market', 'number', 'people', 'system', 'weight', 'window'],
                       ['coffee', 'course', 'design', 'family', 'future', 'market', 'online', 'people', 'review', 'window'],
                       ['coffee', 'memory', 'number', 'police', 'review', 'signal', 'silver', 'system', 'travel', 'window'],
                       ['coffee', 'family', 'future', 'handle', 'memory', 'number', 'police', 'signal', 'silver', 'system'],
                       ['coffee', 'course', 'credit', 'design', 'future', 'ground', 'number', 'second', 'travel', 'window'],
                       ['coffee', 'credit', 'family', 'future', 'handle', 'number', 'online', 'people', 'review', 'system'],
                       ['coffee', 'ground', 'handle', 'market', 'normal', 'people', 'second', 'system', 'weight', 'window'],
                       ['coffee', 'course', 'credit', 'design', 'family', 'ground', 'online', 'system', 'travel', 'window'],
                       ['coffee', 'course', 'design', 'family', 'handle', 'market', 'number', 'online', 'people', 'second'],
                       ['coffee', 'course', 'credit', 'family', 'handle', 'normal', 'number', 'review', 'second', 'system'],
                       ['coffee', 'design', 'family', 'ground', 'market', 'number', 'online', 'review', 'second', 'travel'],
                       ['coffee', 'course', 'family', 'market', 'normal', 'people', 'review', 'second', 'travel', 'window'],
                       ['course', 'design', 'ground', 'handle', 'market', 'number', 'people', 'second', 'travel', 'weight'],
                       ['course', 'family', 'ground', 'memory', 'online', 'police', 'review', 'second', 'signal', 'silver'],
                       ['course', 'design', 'future', 'memory', 'normal', 'number', 'online', 'police', 'signal', 'silver'],
                       ['course', 'design', 'future', 'ground', 'market', 'normal', 'people', 'review', 'second', 'window'],
                       ['course', 'credit', 'ground', 'handle', 'normal', 'number', 'people', 'review', 'second', 'travel'],
                       ['course', 'credit', 'future', 'handle', 'market', 'review', 'second', 'system', 'travel', 'window'],
                       ['course', 'credit', 'design', 'family', 'ground', 'handle', 'market', 'second', 'weight', 'window'],
                       ['course', 'design', 'family', 'ground', 'handle', 'market', 'online', 'review', 'second', 'system'],
                       ['course', 'future', 'ground', 'normal', 'number', 'online', 'review', 'second', 'travel', 'window'],
                       ['course', 'family', 'future', 'ground', 'normal', 'online', 'people', 'review', 'system', 'window'],
                       ['course', 'ground', 'handle', 'market', 'memory', 'online', 'people', 'police', 'signal', 'silver'],
                       ['course', 'credit', 'design', 'ground', 'memory', 'online', 'police', 'signal', 'silver', 'travel'],
                       ['credit', 'design', 'family', 'handle', 'normal', 'number', 'online', 'review', 'travel', 'window'],
                       ['credit', 'design', 'family', 'future', 'ground', 'handle', 'second', 'system', 'travel', 'weight'],
                       ['credit', 'ground', 'market', 'memory', 'people', 'police', 'second', 'signal', 'silver', 'system'],
                       ['credit', 'family', 'future', 'ground', 'market', 'normal', 'second', 'system', 'weight', 'window'],
                       ['credit', 'design', 'future', 'ground', 'handle', 'market', 'number', 'review', 'system', 'weight'],
                       ['credit', 'handle', 'market', 'normal', 'number', 'online', 'people', 'review', 'system', 'window'],
                       ['design', 'future', 'memory', 'number', 'people', 'police', 'signal', 'silver', 'system', 'window'],
                       ['design', 'family', 'future', 'market', 'normal', 'number', 'online', 'review', 'second', 'system'],
                       ['design', 'future', 'market', 'number', 'people', 'review', 'second', 'system', 'weight', 'window'],
                       ['family', 'future', 'ground', 'memory', 'number', 'online', 'people', 'police', 'signal', 'silver'],
                       ['future', 'handle', 'memory', 'people', 'police', 'second', 'signal', 'silver', 'system', 'travel'],
                       ['market', 'memory', 'number', 'online', 'people', 'police', 'review', 'signal', 'silver', 'travel']]





# Generate trial list
def generate_trial_list(condition, meanings):
    print(condition,meanings)
    shuffled_meanings = shuffle(meanings)
    if condition == 'baseline': # in which individual meaning occurs 27 times and each pair occur 3 times
        trial_list =  [ 
                      # 0*27 + (1,2,3,4,5,6,7,8,9)*3
                      [shuffled_meanings[0],shuffled_meanings[1]],[shuffled_meanings[0],shuffled_meanings[1]],[shuffled_meanings[0],shuffled_meanings[1]], 
                      [shuffled_meanings[0],shuffled_meanings[2]],[shuffled_meanings[0],shuffled_meanings[2]],[shuffled_meanings[0],shuffled_meanings[2]], 
                      [shuffled_meanings[0],shuffled_meanings[3]],[shuffled_meanings[0],shuffled_meanings[3]],[shuffled_meanings[0],shuffled_meanings[3]],
                      [shuffled_meanings[0],shuffled_meanings[4]],[shuffled_meanings[0],shuffled_meanings[4]],[shuffled_meanings[0],shuffled_meanings[4]],
                      [shuffled_meanings[0],shuffled_meanings[5]],[shuffled_meanings[0],shuffled_meanings[5]],[shuffled_meanings[0],shuffled_meanings[5]],
                      [shuffled_meanings[0],shuffled_meanings[6]],[shuffled_meanings[0],shuffled_meanings[6]],[shuffled_meanings[0],shuffled_meanings[6]],
                      [shuffled_meanings[0],shuffled_meanings[7]],[shuffled_meanings[0],shuffled_meanings[7]],[shuffled_meanings[0],shuffled_meanings[7]], 
                      [shuffled_meanings[0],shuffled_meanings[8]],[shuffled_meanings[0],shuffled_meanings[8]],[shuffled_meanings[0],shuffled_meanings[8]],
                      [shuffled_meanings[0],shuffled_meanings[9]],[shuffled_meanings[0],shuffled_meanings[9]],[shuffled_meanings[0],shuffled_meanings[9]],
                      # 1*24 + (2,3,4,5,6,7,8,9)*3
                      [shuffled_meanings[1],shuffled_meanings[2]],[shuffled_meanings[1],shuffled_meanings[2]],[shuffled_meanings[1],shuffled_meanings[2]], 
                      [shuffled_meanings[1],shuffled_meanings[3]],[shuffled_meanings[1],shuffled_meanings[3]],[shuffled_meanings[1],shuffled_meanings[3]], 
                      [shuffled_meanings[1],shuffled_meanings[4]],[shuffled_meanings[1],shuffled_meanings[4]],[shuffled_meanings[1],shuffled_meanings[4]],
                      [shuffled_meanings[1],shuffled_meanings[5]],[shuffled_meanings[1],shuffled_meanings[5]],[shuffled_meanings[1],shuffled_meanings[5]],
                      [shuffled_meanings[1],shuffled_meanings[6]],[shuffled_meanings[1],shuffled_meanings[6]],[shuffled_meanings[1],shuffled_meanings[6]], 
                      [shuffled_meanings[1],shuffled_meanings[7]],[shuffled_meanings[1],shuffled_meanings[7]],[shuffled_meanings[1],shuffled_meanings[7]], 
                      [shuffled_meanings[1],shuffled_meanings[8]],[shuffled_meanings[1],shuffled_meanings[8]],[shuffled_meanings[1],shuffled_meanings[8]], 
                      [shuffled_meanings[1],shuffled_meanings[9]],[shuffled_meanings[1],shuffled_meanings[9]],[shuffled_meanings[1],shuffled_meanings[9]],
                      # 2*21 + (3,4,5,6,7,8,9)*3
                      [shuffled_meanings[2],shuffled_meanings[3]],[shuffled_meanings[2],shuffled_meanings[3]],[shuffled_meanings[2],shuffled_meanings[3]],
                      [shuffled_meanings[2],shuffled_meanings[4]],[shuffled_meanings[2],shuffled_meanings[4]],[shuffled_meanings[2],shuffled_meanings[4]],
                      [shuffled_meanings[2],shuffled_meanings[5]],[shuffled_meanings[2],shuffled_meanings[5]],[shuffled_meanings[2],shuffled_meanings[5]],
                      [shuffled_meanings[2],shuffled_meanings[6]],[shuffled_meanings[2],shuffled_meanings[6]],[shuffled_meanings[2],shuffled_meanings[6]],
                      [shuffled_meanings[2],shuffled_meanings[7]],[shuffled_meanings[2],shuffled_meanings[7]],[shuffled_meanings[2],shuffled_meanings[7]],
                      [shuffled_meanings[2],shuffled_meanings[8]],[shuffled_meanings[2],shuffled_meanings[8]],[shuffled_meanings[2],shuffled_meanings[8]],
                      [shuffled_meanings[2],shuffled_meanings[9]],[shuffled_meanings[2],shuffled_meanings[9]],[shuffled_meanings[2],shuffled_meanings[9]],
                      # 3*18 + (4,5,6,7,8,9)*3
                      [shuffled_meanings[3],shuffled_meanings[4]],[shuffled_meanings[3],shuffled_meanings[4]],[shuffled_meanings[3],shuffled_meanings[4]],
                      [shuffled_meanings[3],shuffled_meanings[5]],[shuffled_meanings[3],shuffled_meanings[5]],[shuffled_meanings[3],shuffled_meanings[5]], 
                      [shuffled_meanings[3],shuffled_meanings[6]],[shuffled_meanings[3],shuffled_meanings[6]],[shuffled_meanings[3],shuffled_meanings[6]],
                      [shuffled_meanings[3],shuffled_meanings[7]],[shuffled_meanings[3],shuffled_meanings[7]],[shuffled_meanings[3],shuffled_meanings[7]], 
                      [shuffled_meanings[3],shuffled_meanings[8]],[shuffled_meanings[3],shuffled_meanings[8]],[shuffled_meanings[3],shuffled_meanings[8]], 
                      [shuffled_meanings[3],shuffled_meanings[9]],[shuffled_meanings[3],shuffled_meanings[9]],[shuffled_meanings[3],shuffled_meanings[9]], 
                      # 4*15 + (5,6,7,8,9)*3
                      [shuffled_meanings[4],shuffled_meanings[5]],[shuffled_meanings[4],shuffled_meanings[5]],[shuffled_meanings[4],shuffled_meanings[5]],
                      [shuffled_meanings[4],shuffled_meanings[6]],[shuffled_meanings[4],shuffled_meanings[6]],[shuffled_meanings[4],shuffled_meanings[6]],
                      [shuffled_meanings[4],shuffled_meanings[7]],[shuffled_meanings[4],shuffled_meanings[7]],[shuffled_meanings[4],shuffled_meanings[7]], 
                      [shuffled_meanings[4],shuffled_meanings[8]],[shuffled_meanings[4],shuffled_meanings[8]],[shuffled_meanings[4],shuffled_meanings[8]],
                      [shuffled_meanings[4],shuffled_meanings[9]],[shuffled_meanings[4],shuffled_meanings[9]],[shuffled_meanings[4],shuffled_meanings[9]],
                      # 5*12 + (6,7,8,9)*3
                      [shuffled_meanings[5],shuffled_meanings[6]],[shuffled_meanings[5],shuffled_meanings[6]],[shuffled_meanings[5],shuffled_meanings[6]],
                      [shuffled_meanings[5],shuffled_meanings[7]],[shuffled_meanings[5],shuffled_meanings[7]],[shuffled_meanings[5],shuffled_meanings[7]],
                      [shuffled_meanings[5],shuffled_meanings[8]],[shuffled_meanings[5],shuffled_meanings[8]],[shuffled_meanings[5],shuffled_meanings[8]],
                      [shuffled_meanings[5],shuffled_meanings[9]],[shuffled_meanings[5],shuffled_meanings[9]],[shuffled_meanings[5],shuffled_meanings[9]], 
                      # 6*9 + (7,8,9)*3
                      [shuffled_meanings[6],shuffled_meanings[7]],[shuffled_meanings[6],shuffled_meanings[7]],[shuffled_meanings[6],shuffled_meanings[7]],
                      [shuffled_meanings[6],shuffled_meanings[8]],[shuffled_meanings[6],shuffled_meanings[8]],[shuffled_meanings[6],shuffled_meanings[8]],
                      [shuffled_meanings[6],shuffled_meanings[9]],[shuffled_meanings[6],shuffled_meanings[9]],[shuffled_meanings[6],shuffled_meanings[9]],
                      # 7*6 + (8,9)*3
                      [shuffled_meanings[7],shuffled_meanings[8]],[shuffled_meanings[7],shuffled_meanings[8]],[shuffled_meanings[7],shuffled_meanings[8]],
                      [shuffled_meanings[7],shuffled_meanings[9]],[shuffled_meanings[7],shuffled_meanings[9]],[shuffled_meanings[7],shuffled_meanings[9]],
                      # 8*3 + (9)*3
                      [shuffled_meanings[8],shuffled_meanings[9]],[shuffled_meanings[8],shuffled_meanings[9]],[shuffled_meanings[8],shuffled_meanings[9]]]
    elif condition == 'target': # in which individual meanings occur 27 times and pairs follow the frequency of 11:11:5:2:2
        trial_list =  [
                      # (0-1; 2-3; 4-5)*11 times each = 33. *** 0,1,2,3,4,5 are "target meanings".
                      [shuffled_meanings[0],shuffled_meanings[1]],[shuffled_meanings[0],shuffled_meanings[1]],[shuffled_meanings[0],shuffled_meanings[1]],[shuffled_meanings[0],shuffled_meanings[1]],[shuffled_meanings[0],shuffled_meanings[1]],[shuffled_meanings[0],shuffled_meanings[1]],[shuffled_meanings[0],shuffled_meanings[1]],[shuffled_meanings[0],shuffled_meanings[1]],[shuffled_meanings[0],shuffled_meanings[1]],[shuffled_meanings[0],shuffled_meanings[1]],[shuffled_meanings[0],shuffled_meanings[1]],
                      [shuffled_meanings[2],shuffled_meanings[3]],[shuffled_meanings[2],shuffled_meanings[3]],[shuffled_meanings[2],shuffled_meanings[3]],[shuffled_meanings[2],shuffled_meanings[3]],[shuffled_meanings[2],shuffled_meanings[3]],[shuffled_meanings[2],shuffled_meanings[3]],[shuffled_meanings[2],shuffled_meanings[3]],[shuffled_meanings[2],shuffled_meanings[3]],[shuffled_meanings[2],shuffled_meanings[3]],[shuffled_meanings[2],shuffled_meanings[3]],[shuffled_meanings[2],shuffled_meanings[3]],
                      [shuffled_meanings[4],shuffled_meanings[5]],[shuffled_meanings[4],shuffled_meanings[5]],[shuffled_meanings[4],shuffled_meanings[5]],[shuffled_meanings[4],shuffled_meanings[5]],[shuffled_meanings[4],shuffled_meanings[5]],[shuffled_meanings[4],shuffled_meanings[5]],[shuffled_meanings[4],shuffled_meanings[5]],[shuffled_meanings[4],shuffled_meanings[5]],[shuffled_meanings[4],shuffled_meanings[5]],[shuffled_meanings[4],shuffled_meanings[5]],[shuffled_meanings[4],shuffled_meanings[5]],
                       # (6-7; 6-8; 6-9; 7-8; 7-9; 8-9)*5 times each = 30. *** 6,7,8,9 are "distractors"
                      [shuffled_meanings[6],shuffled_meanings[7]],[shuffled_meanings[6],shuffled_meanings[7]],[shuffled_meanings[6],shuffled_meanings[7]],[shuffled_meanings[6],shuffled_meanings[7]],[shuffled_meanings[6],shuffled_meanings[7]],
                      [shuffled_meanings[6],shuffled_meanings[8]],[shuffled_meanings[6],shuffled_meanings[8]],[shuffled_meanings[6],shuffled_meanings[8]],[shuffled_meanings[6],shuffled_meanings[8]],[shuffled_meanings[6],shuffled_meanings[8]],
                      [shuffled_meanings[6],shuffled_meanings[9]],[shuffled_meanings[6],shuffled_meanings[9]],[shuffled_meanings[6],shuffled_meanings[9]],[shuffled_meanings[6],shuffled_meanings[9]],[shuffled_meanings[6],shuffled_meanings[9]],
                      [shuffled_meanings[7],shuffled_meanings[8]],[shuffled_meanings[7],shuffled_meanings[8]],[shuffled_meanings[7],shuffled_meanings[8]],[shuffled_meanings[7],shuffled_meanings[8]],[shuffled_meanings[7],shuffled_meanings[8]],
                      [shuffled_meanings[7],shuffled_meanings[9]],[shuffled_meanings[7],shuffled_meanings[9]],[shuffled_meanings[7],shuffled_meanings[9]],[shuffled_meanings[7],shuffled_meanings[9]],[shuffled_meanings[7],shuffled_meanings[9]],
                      [shuffled_meanings[8],shuffled_meanings[9]],[shuffled_meanings[8],shuffled_meanings[9]],[shuffled_meanings[8],shuffled_meanings[9]],[shuffled_meanings[8],shuffled_meanings[9]],[shuffled_meanings[8],shuffled_meanings[9]],
                       # (m-n) = (target-distractor), 24 pair orccurring 2 times = 48.
                      [shuffled_meanings[0],shuffled_meanings[6]],[shuffled_meanings[0],shuffled_meanings[6]],
                      [shuffled_meanings[0],shuffled_meanings[7]],[shuffled_meanings[0],shuffled_meanings[7]],
                      [shuffled_meanings[0],shuffled_meanings[8]],[shuffled_meanings[0],shuffled_meanings[8]],
                      [shuffled_meanings[0],shuffled_meanings[9]],[shuffled_meanings[0],shuffled_meanings[9]],
                      [shuffled_meanings[1],shuffled_meanings[6]],[shuffled_meanings[1],shuffled_meanings[6]],
                      [shuffled_meanings[1],shuffled_meanings[7]],[shuffled_meanings[1],shuffled_meanings[7]],
                      [shuffled_meanings[1],shuffled_meanings[8]],[shuffled_meanings[1],shuffled_meanings[8]],
                      [shuffled_meanings[1],shuffled_meanings[9]],[shuffled_meanings[1],shuffled_meanings[9]],
                      [shuffled_meanings[2],shuffled_meanings[6]],[shuffled_meanings[2],shuffled_meanings[6]],
                      [shuffled_meanings[2],shuffled_meanings[7]],[shuffled_meanings[2],shuffled_meanings[7]],
                      [shuffled_meanings[2],shuffled_meanings[8]],[shuffled_meanings[2],shuffled_meanings[8]],
                      [shuffled_meanings[2],shuffled_meanings[9]],[shuffled_meanings[2],shuffled_meanings[9]],
                      [shuffled_meanings[3],shuffled_meanings[6]],[shuffled_meanings[3],shuffled_meanings[6]],
                      [shuffled_meanings[3],shuffled_meanings[7]],[shuffled_meanings[3],shuffled_meanings[7]],
                      [shuffled_meanings[3],shuffled_meanings[8]],[shuffled_meanings[3],shuffled_meanings[8]],
                      [shuffled_meanings[3],shuffled_meanings[9]],[shuffled_meanings[3],shuffled_meanings[9]],
                      [shuffled_meanings[4],shuffled_meanings[6]],[shuffled_meanings[4],shuffled_meanings[6]],
                      [shuffled_meanings[4],shuffled_meanings[7]],[shuffled_meanings[4],shuffled_meanings[7]],
                      [shuffled_meanings[4],shuffled_meanings[8]],[shuffled_meanings[4],shuffled_meanings[8]],
                      [shuffled_meanings[4],shuffled_meanings[9]],[shuffled_meanings[4],shuffled_meanings[9]],
                      [shuffled_meanings[5],shuffled_meanings[6]],[shuffled_meanings[5],shuffled_meanings[6]],
                      [shuffled_meanings[5],shuffled_meanings[7]],[shuffled_meanings[5],shuffled_meanings[7]],
                      [shuffled_meanings[5],shuffled_meanings[8]],[shuffled_meanings[5],shuffled_meanings[8]],
                      [shuffled_meanings[5],shuffled_meanings[9]],[shuffled_meanings[5],shuffled_meanings[9]],
                       # target-target' pairs, (4+4+2+2+0+0=12)*2 = 24.
                      [shuffled_meanings[0],shuffled_meanings[2]],[shuffled_meanings[0],shuffled_meanings[3]],[shuffled_meanings[0],shuffled_meanings[4]],[shuffled_meanings[0],shuffled_meanings[5]],
                      [shuffled_meanings[0],shuffled_meanings[2]],[shuffled_meanings[0],shuffled_meanings[3]],[shuffled_meanings[0],shuffled_meanings[4]],[shuffled_meanings[0],shuffled_meanings[5]],
                      [shuffled_meanings[1],shuffled_meanings[2]],[shuffled_meanings[1],shuffled_meanings[3]],[shuffled_meanings[1],shuffled_meanings[4]],[shuffled_meanings[1],shuffled_meanings[5]],
                      [shuffled_meanings[1],shuffled_meanings[2]],[shuffled_meanings[1],shuffled_meanings[3]],[shuffled_meanings[1],shuffled_meanings[4]],[shuffled_meanings[1],shuffled_meanings[5]],
                      [shuffled_meanings[2],shuffled_meanings[4]],[shuffled_meanings[2],shuffled_meanings[5]],
                      [shuffled_meanings[2],shuffled_meanings[4]],[shuffled_meanings[2],shuffled_meanings[5]],
                      [shuffled_meanings[3],shuffled_meanings[4]],[shuffled_meanings[3],shuffled_meanings[5]],
                      [shuffled_meanings[3],shuffled_meanings[4]],[shuffled_meanings[3],shuffled_meanings[5]],
                      ]
    print(trial_list)
    return trial_list

#target_list = [['ankle','window'], ['princess', 'island'], ['belief', 'flower'], 
 #              ['liquor', 'century'], ['dollar', 'people'], ['stomach', 'bedroom'],
  #             ['doctor', 'temper'], ['river', 'valley'], ['apple', 'sunshine'],
   #            ['winner', 'presence'],['lawyer', 'banker'], ['reality', 'illusion'],
    #           ['argument', 'agreement'], ['apartment', 'furniture'], ['camera', 'president']]


###################################################################
############################ utility ##############################
###################################################################

# for randomization
def shuffle(l):
    return random.sample(l, len(l))

# for converting message strings to JSON string
def send_message_by_id(client_id, message):
    client = global_participant_data[client_id]['client_info']
    server.send_message(client, json.dumps(message))

# for checking all clients are in the list_of_ids and are connected to server
# if so, clients will be in global_participant_data
def all_connected(list_of_ids):
    connected_status = [id in global_participant_data for id in list_of_ids]
    if sum(connected_status) == len(list_of_ids):
        return True 
    else:
        return False

# for notifying any client's dropping out
def notify_stranded(list_of_ids):
    for id in list_of_ids:
        if id in global_participant_data:
            send_message_by_id(id, {"command_type": "PartnerDropout"})

###################################################################
########### connecting, disconnecting, sending messages ###########
###################################################################

# connecting
def new_client(client, server):
    client_id = client['id']
    print("New client connected and was given id %id" % client_id)
    global_participant_data[client_id] = {'client_info': client}
    #in giving instructions to clients
    enter_phase(client_id, "Start")

# disconnecting
def client_left(client, server):
    client_id = client['id']
    print("Client(%d) disconnected" % client['id'])
    if client_id in unpaired_clients:
        unpaired_clients.remove(client_id)
    # leaving due to End
    if 'partner' in global_participant_data[client_id]:
        if global_participant_data[client_id]['phase'] != 'End':
            partner = global_participant_data[client_id]['partner']
            notify_stranded([partner])
    del global_participant_data[client_id]

# parsing the messages from clients in json dictionary
def message_received(client, server, message):
    print("Client(%d) said: %s" % (client['id'], message))
    # other possible responses
    response = json.loads(message)
    response_code = response['response_type']
    handle_client_response(client['id'], response_code, response)

###################################################################
############################ phases ###############################
###################################################################

# check the current phase and moves towards
def progress_phase(client_id):
    current_phase = global_participant_data[client_id]['phase']
    current_phase_i = phase_sequence.index(current_phase)
    next_phase_i = current_phase_i + 1
    next_phase = phase_sequence[next_phase_i]
    enter_phase(client_id, next_phase)

# trigger the next phase
def enter_phase(client_id, phase):
    #update the phase info
    global_participant_data[client_id]['phase'] = phase
    #start the experiment
    if phase == 'Start':
        progress_phase(client_id)

    elif phase == 'PairParticipants':
        #send message to those clients who are in the waiting room
        send_message_by_id(client_id, {'command_type': "WaitingRoom"})
        unpaired_clients.append(client_id)
        #if immediately paired, move on
        #if two unpaired clients, remove from the unpaired list, and pair them
        if (len(unpaired_clients)%2 == 0):
            unpaired_one = unpaired_clients[0]
            unpaired_two = unpaired_clients[1]
            unpaired_clients.remove(unpaired_one)
            unpaired_clients.remove(unpaired_two)
            #put them in global data
            global_participant_data[unpaired_one]['partner'] = unpaired_two
            global_participant_data[unpaired_two]['partner'] = unpaired_one
            #QT, I moved a bunch of stuff down here!
            # select random condition and  
            this_pair_condition = random.choice(['baseline', 'target'])

            # select random signals
            signal_short_list = random.sample(signal_short, 5)
            signal_long_list = random.sample(signal_long, 5)
            print(signal_short_list)
            print(signal_long_list)
            this_pair_signals = shuffle(signal_short_list + signal_long_list)
            
            print(this_pair_signals)

            # select random meanings
            this_pair_meanings = random.choice(andres_meaning_list)
            print(this_pair_meanings)

            this_pair_trial_list = generate_trial_list(this_pair_condition,this_pair_meanings)

            shuffled_targets = shuffle(this_pair_trial_list)
            #QT - could also gebnerate a list of signals at this point and store it in the same way as shuffled_targets
            for c in [unpaired_one, unpaired_two]:
                global_participant_data[c]['signals'] = this_pair_signals
                global_participant_data[c]['trial_list'] = shuffled_targets
                global_participant_data[c]['shared_trial_counter'] = 0
                progress_phase(c)

    # after paired, they move onto instruction trial
    elif phase == 'Interaction':
        print('initialising for interaction')
        send_instructions(client_id, phase)
    
    # when hit the end
    elif phase == 'End':
        send_message_by_id(client_id, {"command_type": "EndExperiment"})

###################################################################
########################## LOOOOOOOOOP ############################
###################################################################

############## while handling different responses #################
def handle_client_response(client_id, response_code, full_response):
    print('handle_client_response', client_id, response_code, full_response)
    #1. client_info
    if response_code == "CLIENT_INFO":
        global_participant_data[client_id]['participantID'] = full_response['client_info']
    #2. interaction_instruction_complete
    elif response_code == "INTERACTION_INSTRUCTIONS_COMPLETE":
        initiate_interaction(client_id)
    #3. response in two roles
    elif response_code == "RESPONSE" and full_response['role']=='Sender':
        handle_sender_response(client_id, full_response)
    elif response_code == "RESPONSE" and full_response['role']=='Receiver':
        handle_receiver_response(client_id, full_response)
    #4. finished_feedback: switch roles
    elif response_code == "FINISHED_FEEDBACK":
        swap_roles_and_progress(client_id)
    #5. nonresponsive_partner
    elif response_code == "NONRESPONSIVE_PARTNER":
        pass 

###################### trial progressions #########################
#1. after instruction
def initiate_interaction(client_id):
    print("in initiate_interaction",client_id)
    partner_id = global_participant_data[client_id]['partner']
    list_of_participants = [client_id, partner_id]
    # check if both are still connected
    if not(all_connected(list_of_participants)):
        notify_stranded(list_of_participants)
    else:
        send_message_by_id(client_id, {"command_type": "WaitForPartner"})
        partner_role = global_participant_data[partner_id]['role']
        #if ready to start the game
        if partner_role == 'ReadyToInteract':
            print('Starting interaction')
            #randomize sender and receiver
            for client, role in zip(list_of_participants, shuffle(["Sender", "Receiver"])):
                global_participant_data[client]['role'] = role
            start_interaction_trial(list_of_participants)
        else: global_participant_data[client_id]['role'] = 'ReadyToInteract'

#2. sending distinct instructions to sender and receiver
def start_interaction_trial(list_of_participants):
    #check if both/all are still connected; if not, notify
    if not(all_connected(list_of_participants)):
        notify_stranded(list_of_participants)
    else:
        #figure out who is the sender
        sender_id = [id for id in list_of_participants if global_participant_data[id]['role']=="Sender"][0]
        #retrieve their trial list and trial counter
        trial_counter = global_participant_data[sender_id]['shared_trial_counter']
        trial_list = global_participant_data[sender_id]['trial_list']
        ntrials = len(trial_list)
        #check if the sender has more trials to run - if not, move on
        if trial_counter >= ntrials:
            for c in list_of_participants:
                progress_phase(c)
        else:
            receiver_id = global_participant_data[sender_id]['partner']
            receiver_participant_id = global_participant_data[receiver_id]['participantID']
            target_plus_foil = trial_list[trial_counter]
            target = target_plus_foil[0]
            foil = target_plus_foil[1]
            signals = global_participant_data[sender_id]['signals']
            for c in list_of_participants:
                this_role = global_participant_data[c]['role']
                if this_role == "Sender":
                    instruction_string = {"command_type": "Sender",
                                          "target_meaning": target,
                                          "foil_meaning": foil,
                                          "signals": signals,
                                          "trial_counter": trial_counter,
                                          "n_trials": ntrials,
                                          "partner_id": receiver_participant_id}
                                          # show the counter on the screen
                else:
                    instruction_string = {"command_type": "WaitForPartner"}
                send_message_by_id(c, instruction_string)

#3. on sender's response to server and server sending this response to receiver
def handle_sender_response(sender_id, sender_response):
    print('handle_sender_response', sender_response)
    receiver_id = global_participant_data[sender_id]['partner']
    if not(all_connected([receiver_id])):
        notify_stranded([sender_id])
    else:
        #look up the target in the sender trial list
        trial_counter = global_participant_data[sender_id]['shared_trial_counter']
        trial_list = global_participant_data[sender_id]['trial_list']
        ntrials = len(trial_list)
        target_plus_foil = trial_list[trial_counter]
        target = target_plus_foil[0]
        foil = target_plus_foil[1]
        #the sender's response is the signal
        
        sender_participant_id = global_participant_data[sender_id]['participantID']
        send_message_by_id(sender_id, {"command_type": "WaitForPartner"})
        #server sends this response to receiver
        send_message_by_id(receiver_id,
                                       {"command_type": "Receiver",
                                        "sender_signal": sender_response['response'],
                                        "target_meaning": target, ## see above - I retrieved this from the sender's trial list
                                        "foil_meaning":foil,
                                        "trial_counter": trial_counter,
                                        "n_trials": ntrials,
                                        "partner_id": sender_participant_id})

#4. receiver's guess and feedback
def handle_receiver_response(receiver_id, receiver_response):
    print("in handle_receiver_response")
    sender_id = global_participant_data[receiver_id]['partner']
    if not(all_connected([sender_id, receiver_id])):
        notify_stranded([sender_id, receiver_id])
    else:
        #which meaning pair:
        trial_n = global_participant_data[sender_id]['shared_trial_counter']
        target_plus_foil = global_participant_data[sender_id]['trial_list'][trial_n]
        target = target_plus_foil[0]
        #sender's selected signal & receiver's meaning guess
        signal = receiver_response['sender_signal']
        guess = receiver_response['response']
        if target == guess:
            score = 1
        else:
            score = 0
        feedback = {"command_type": "Feedback", "score": score,
                    "target": target, "signal": signal, "guess": guess}
        for c in [sender_id, receiver_id]:
            send_message_by_id(c, feedback)

#5. done one trial and switch the role
def swap_roles_and_progress(client_id):
    print('swap roles',client_id)
    partner_id = global_participant_data[client_id]['partner']
    if not(all_connected([client_id,partner_id])):
        notify_stranded([client_id,partner_id])
    else:
        #increment global counter - both participants will do this independently when they reach this point
        global_participant_data[client_id]['shared_trial_counter'] += 1

        this_client_role = global_participant_data[client_id]['role']
        partner_role = global_participant_data[partner_id]['role']
        if partner_role=='WaitingToSwitch':
            if this_client_role=='Sender':
                global_participant_data[client_id]['role'] = "Receiver"
                global_participant_data[partner_id]['role'] = "Sender"
            else:
                global_participant_data[client_id]['role'] = "Sender"
                global_participant_data[partner_id]['role'] = "Receiver"
            #next trial
            start_interaction_trial([client_id,partner_id])
        #Otherwise your partner is not yet ready, so just flag up that you are
        else:
            global_participant_data[client_id]['role'] = "WaitingToSwitch"

###################################################################
################### Instruction between Blocks ####################
###################################################################

def send_instructions(client_id,phase):
    if phase=='Interaction':
        #set role
        global_participant_data[client_id]['role'] = "ReadingInstructions"
        send_message_by_id(client_id,{"command_type": "Instructions","instruction_type": "Interaction"})

###################################################################
######################## Start the Server #########################
###################################################################

PORT=9027 #will this run on port 9001 ?

#standard stuff here from the websocket_server code
print('starting up')
server = WebsocketServer(PORT,'0.0.0.0')
server.set_fn_new_client(new_client)
server.set_fn_client_left(client_left)
server.set_fn_message_received(message_received)
server.run_forever()